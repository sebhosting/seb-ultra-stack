# Changelog

- v1.1.9 – banner-first README, fancy docs, auto docs deploy, installer, compose
